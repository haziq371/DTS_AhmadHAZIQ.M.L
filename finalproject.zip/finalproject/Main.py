import tkinter as tk
from data_manager import DataManager
from database_manager import DatabaseManager
from app import App

if __name__ == "__main__":
    root = tk.Tk()
    data_manager = DataManager(user='root', password='', host='localhost', database='food_waste')
    db_manager = DatabaseManager(user='root', password='', host='localhost', database='food_waste')
    app = App(root, data_manager, db_manager)
    root.mainloop()
