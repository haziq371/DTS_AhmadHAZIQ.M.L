import tkinter as tk
from tkinter import messagebox, ttk
import matplotlib.pyplot as plt
import pandas as pd
from data_manager import DataManager
from database_manager import DatabaseManager

class App:
    def __init__(self, root, data_manager, db_manager):
        self.data_manager = data_manager
        self.root = root
        self.root.title("Country Data Statistics")
        self.db_manager = db_manager

        # Dropdown menu untuk memilih negara
        self.country_label = tk.Label(root, text="Country")
        self.country_label.pack()
        self.country_var = tk.StringVar()
        self.country_dropdown = ttk.Combobox(root, textvariable=self.country_var)
        self.country_dropdown['values'] = self.data_manager.get_countries()
        self.country_dropdown.pack()

        # Dropdown menu untuk memilih wilayah
        self.region_label = tk.Label(root, text="Region")
        self.region_label.pack()
        self.region_var = tk.StringVar()
        self.region_dropdown = ttk.Combobox(root, textvariable=self.region_var)
        self.region_dropdown['values'] = self.data_manager.get_regions()
        self.region_dropdown.pack()

        # Tombol untuk mencari data
        self.find_button = tk.Button(root, text="Find Data", command=self.find_data)
        self.find_button.pack()

        # Treeview untuk menampilkan data
        self.tree = ttk.Treeview(root, columns=("Country", "combined_figures_kg_per_capita_year", "household_estimate_kg_per_capita_year",
                                                "household_estimate_tonnes_year", "retail_estimate_kg_per_capita_year",
                                                "retail_estimate_tonnes_year", "food_service_estimate_kg_per_capita_year",
                                                "confidence_in_estimate", "m49_code", "region"),
                                 show='headings')
        self.tree.heading("Country", text="Country")
        self.tree.heading("combined_figures_kg_per_capita_year", text="Combined Figures (kg/capita/year)")
        self.tree.heading("household_estimate_kg_per_capita_year", text="Household Estimate (kg/capita/year)")
        self.tree.heading("household_estimate_tonnes_year", text="Household Estimate (tonnes/year)")
        self.tree.heading("retail_estimate_kg_per_capita_year", text="Retail Estimate (kg/capita/year)")
        self.tree.heading("retail_estimate_tonnes_year", text="Retail Estimate (tonnes/year)")
        self.tree.heading("food_service_estimate_kg_per_capita_year", text="Food Service Estimate (kg/capita/year)")
        self.tree.heading("confidence_in_estimate", text="Confidence in Estimate")
        self.tree.heading("m49_code", text="M49 Code")
        self.tree.heading("region", text="Region")
        self.tree.pack()

    def find_data(self):
        country_name = self.country_var.get()
        region = self.region_var.get()

        if country_name:
            country_data = self.data_manager.find_country_data(country_name)
        elif region:
            country_data = self.data_manager.find_region_data(region)
        else:
            messagebox.showwarning("Input Error", "Please select a country or region.")
            return

        if not country_data.empty:
            # Kosongkan Treeview sebelum menambahkan data baru
            for item in self.tree.get_children():
                self.tree.delete(item)

            # Menambahkan data ke Treeview
            for _, row in country_data.iterrows():
                self.tree.insert("", tk.END, values=tuple(row))

            # Hitung rata-rata perbedaan
            mean_comparison = self.data_manager.calculate_statistics(country_data)
            stats_str = f"Selisih perbandingan: {mean_comparison}"
            messagebox.showinfo("Country Data", f"Statistics:\n{stats_str}")

            # Simpan statistik ke database
            self.db_manager.save_statistics(country_name, 'Value', mean_comparison)

            # Tampilkan grafik
            self.plot_data(country_data)
        else:
            messagebox.showwarning("No Data", "No data found for the specified country or region.")

    def plot_data(self, df):
        if 'household_estimate_tonnes_year' in df.columns and 'retail_estimate_tonnes_year' in df.columns:
            countries = df['Country']
            household_estimates = df['household_estimate_tonnes_year']
            retail_estimates = df['retail_estimate_tonnes_year']

            fig, ax = plt.subplots()
            width = 0.35
            x = range(len(countries))
            ax.bar(x, household_estimates, width, label='Household Estimate')
            ax.bar([p + width for p in x], retail_estimates, width, label='Retail Estimate')

            ax.set_xlabel('Countries')
            ax.set_ylabel('Tonnes/Year')
            ax.set_title('Household vs Retail Estimates')
            ax.set_xticks([p + width/2 for p in x])
            ax.set_xticklabels(countries, rotation=90)
            ax.legend()

            plt.show()

    def __del__(self):
        self.data_manager.close_connection()
        self.db_manager.close_connection()
