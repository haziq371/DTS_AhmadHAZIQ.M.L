import pandas as pd
import mysql.connector

class DataManager:
    def __init__(self, user, password, host, database):
        self.user = user
        self.password = password
        self.host = host
        self.database = database
        self.conn = None
        self.data = pd.DataFrame()  # Inisialisasi dengan DataFrame kosong

        self.connect()
        if self.conn:
            self.load_data()

    def connect(self):
        try:
            self.conn = mysql.connector.connect(
                user=self.user,
                password=self.password,
                host=self.host,
                database=self.database
            )
            print("Database connection established.")
        except mysql.connector.Error as err:
            print(f"Error: {err}")
            self.conn = None

    def load_data(self):
        try:
            query = "SELECT * FROM food_waste_data"
            self.data = pd.read_sql(query, self.conn)
            print("Data loaded successfully:")
            print(self.data.columns)  # Debugging: Print column names
            print(self.data.head())   # Debugging: Print first few rows
        except Exception as err:
            print(f"Error: {err}")
            self.data = pd.DataFrame()  # Inisialisasi dengan DataFrame kosong jika terjadi kesalahan

    def get_regions(self):
        """Return unique regions from the dataset."""
        if 'region' in self.data.columns:
            return self.data['region'].unique().tolist()
        else:
            print("Column 'region' not found in data.")
            return []

    def get_countries(self):
        """Return unique countries from the dataset."""
        if 'Country' in self.data.columns:
            return self.data['Country'].unique().tolist()
        else:
            print("Column 'Country' not found in data.")
            return []

    def find_country_data(self, country_name):
        if 'Country' not in self.data.columns:
            print("Column 'Country' not found in data.")
            return pd.DataFrame()  # Mengembalikan DataFrame kosong jika kolom tidak ditemukan
        return self.data[self.data['Country'] == country_name]

    def find_region_data(self, region):
        if 'region' not in self.data.columns:
            print("Column 'region' not found in data.")
            return pd.DataFrame()  # Mengembalikan DataFrame kosong jika kolom tidak ditemukan
        return self.data[self.data['region'] == region]

    def calculate_statistics(self, df):
        if df.empty:
            return None

        # Periksa apakah kolom yang diperlukan ada dalam DataFrame
        if 'retail_estimate_tonnes_year' not in df.columns or 'household_estimate_tonnes_year' not in df.columns:
            print("Required columns not found in data.")
            return None

        # Ambil kolom yang relevan
        retail_estimates = df['retail_estimate_tonnes_year']
        household_estimates = df['household_estimate_tonnes_year']

        # Hitung perbandingan antara retail estimate dan household estimate
        comparison =  household_estimates - retail_estimates
        mean_comparison = comparison.mean()

        return mean_comparison

    def close_connection(self):
        if self.conn:
            self.conn.close()
            print("Database connection closed.")
