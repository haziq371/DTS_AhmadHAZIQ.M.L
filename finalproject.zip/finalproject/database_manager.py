import mysql.connector
from mysql.connector import errorcode

class DatabaseManager:
    def __init__(self, user, password, host, database):
        self.user = user
        self.password = password
        self.host = host
        self.database = database

    def save_statistics(self, country, column_name, mean_value):
        try:
            conn = mysql.connector.connect(
                user=self.user,
                password=self.password,
                host=self.host,
                database=self.database
            )
            cursor = conn.cursor()
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS statistics (
                id INT AUTO_INCREMENT PRIMARY KEY,
                country VARCHAR(100),
                column_name VARCHAR(100),
                mean_value FLOAT
            )
            """)
            cursor.execute("""
            INSERT INTO statistics (country, column_name, mean_value)
            VALUES (%s, %s, %s)
            """, (country, column_name, mean_value))
            conn.commit()
            print("Data saved successfully.")
        except mysql.connector.Error as err:
            if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
                print("Error: Something is wrong with your username or password")
            elif err.errno == errorcode.ER_BAD_DB_ERROR:
                print("Error: Database does not exist")
            else:
                print("Error:", err)
        finally:
            cursor.close()
            conn.close()

    def close_connection(self):
        """Close the database connection."""
        pass  # Add implementation if needed, currently not used.
